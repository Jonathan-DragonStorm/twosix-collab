# Cosmonic Control Documentation — Offline Releases

Public release artifacts for the Cosmonic Control documentation,
for air-gapped and offline environments. Each release provides:

- **Static tarball** (`cosmonic-docs-<version>.tar.gz` + `.sha256`) —
  extract anywhere and serve with any static web server:

  ```shell
  tar xzf cosmonic-docs-<version>.tar.gz -C /var/www/docs
  python -m http.server 8080 --directory /var/www/docs
  ```

- **Container image** — `ghcr.io/cosmonic/docs:<version>` (also
  tagged `:latest`), an nginx image serving the same content:

  ```shell
  oras copy ghcr.io/cosmonic/docs:<version> registry.internal.example/cosmonic/docs:<version>
  ```

See the [Air-Gapped Installation guide](https://docs.cosmonic.com/docs/operations/air-gapped-installation/)
for the full mirroring workflow.

> Documentation source lives in an internal repository; this repo
> exists so release artifacts are publicly downloadable. Releases are
> published automatically when a `docs-v*` version ships.
