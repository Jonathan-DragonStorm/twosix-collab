{{/*
Expand the name of the chart.
*/}}
{{- define "cosmonic-control-hostgroup.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels for all resources
*/}}
{{- define "cosmonic-control-hostgroup.commonLabels" -}}
app.kubernetes.io/name: {{ include "cosmonic-control-hostgroup.name" . }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
{{- end -}}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cosmonic-control-hostgroup.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- printf "%s-%s" $name .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create the imagePullSecrets section for the chart.
*/}}
{{- define "cosmonic-control-hostgroup.imagePullSecrets" -}}
{{- if .Values.global.image.pullSecrets }}
imagePullSecrets:
{{- range .Values.global.image.pullSecrets }}
  - name: {{ .name }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Name of the ConfigMap materialized from caBundle.contents.
*/}}
{{- define "cosmonic-control-hostgroup.caBundleConfigMapName" -}}
hostgroup-{{ .Values.hostgroup }}-ca-bundle
{{- end -}}

{{/*
Validate caBundle source configuration. Fails the render if more than one
source is set, or none is set when enabled.
*/}}
{{- define "cosmonic-control-hostgroup.caBundleValidate" -}}
{{- $count := 0 -}}
{{- if trim (.Values.caBundle.contents | default "") }}{{ $count = add $count 1 }}{{ end -}}
{{- if .Values.caBundle.existingConfigMap }}{{ $count = add $count 1 }}{{ end -}}
{{- if .Values.caBundle.existingSecret }}{{ $count = add $count 1 }}{{ end -}}
{{- if gt $count 1 -}}
{{- fail "caBundle: only one of contents, existingConfigMap, or existingSecret may be set" -}}
{{- end -}}
{{- if eq $count 0 -}}
{{- fail "caBundle.enabled is true but no source is set: provide one of contents, existingConfigMap, or existingSecret" -}}
{{- end -}}
{{- end -}}

{{/*
Render the caBundle volume entry. Caller must guard on .Values.caBundle.enabled.
*/}}
{{- define "cosmonic-control-hostgroup.caBundleVolume" -}}
{{- include "cosmonic-control-hostgroup.caBundleValidate" . -}}
- name: ca-bundle
  {{- if .Values.caBundle.existingSecret }}
  secret:
    secretName: {{ .Values.caBundle.existingSecret }}
  {{- else if .Values.caBundle.existingConfigMap }}
  configMap:
    name: {{ .Values.caBundle.existingConfigMap }}
  {{- else }}
  configMap:
    name: {{ include "cosmonic-control-hostgroup.caBundleConfigMapName" . }}
  {{- end }}
{{- end -}}

{{/*
Render the caBundle volumeMount entry. Caller must guard on .Values.caBundle.enabled.
*/}}
{{- define "cosmonic-control-hostgroup.caBundleVolumeMount" -}}
- name: ca-bundle
  mountPath: {{ .Values.caBundle.mountPath }}
  subPath: {{ if .Values.caBundle.existingSecret }}{{ .Values.caBundle.secretKey }}{{ else }}{{ .Values.caBundle.configMapKey }}{{ end }}
  readOnly: true
{{- end -}}
