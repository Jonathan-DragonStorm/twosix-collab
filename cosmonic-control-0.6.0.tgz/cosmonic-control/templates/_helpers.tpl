{{/*
Expand the name of the chart.
*/}}
{{- define "cosmonic-control.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels for all resources
*/}}
{{- define "cosmonic-control.commonLabels" -}}
app.kubernetes.io/name: {{ include "cosmonic-control.name" . }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
{{- end -}}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cosmonic-control.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- printf "%s-%s" $name .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "cosmonic-control.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "cosmonic-control.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Create the imagePullSecrets section for the chart.
*/}}
{{- define "cosmonic-control.imagePullSecrets" -}}
{{- if .Values.global.image.pullSecrets }}
imagePullSecrets:
{{- range .Values.global.image.pullSecrets }}
  - name: {{ .name }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Name of the ConfigMap materialized from caBundle.contents.
*/}}
{{- define "cosmonic-control.caBundleConfigMapName" -}}
cosmonic-control-ca-bundle
{{- end -}}

{{/*
Validate caBundle source configuration. Fails the render if more than one
source is set, or none is set when a component opts in via caBundleEnabled.
*/}}
{{- define "cosmonic-control.caBundleValidate" -}}
{{- $count := 0 -}}
{{- if trim (.Values.caBundle.contents | default "") }}{{ $count = add $count 1 }}{{ end -}}
{{- if .Values.caBundle.existingConfigMap }}{{ $count = add $count 1 }}{{ end -}}
{{- if .Values.caBundle.existingSecret }}{{ $count = add $count 1 }}{{ end -}}
{{- if gt $count 1 -}}
{{- fail "caBundle: only one of contents, existingConfigMap, or existingSecret may be set" -}}
{{- end -}}
{{- if eq $count 0 -}}
{{- fail "a component has caBundleEnabled: true but no caBundle source is set: provide one of caBundle.contents, caBundle.existingConfigMap, or caBundle.existingSecret" -}}
{{- end -}}
{{- end -}}

{{/*
True when any component opts in to mounting the caBundle. Used to gate the
chart-managed ConfigMap so we don't materialize an orphan when contents is
set but no component consumes it.
*/}}
{{- define "cosmonic-control.caBundleAnyEnabled" -}}
{{- if or .Values.operator.caBundleEnabled .Values.nexus.caBundleEnabled .Values.envoy.caBundleEnabled -}}
true
{{- end -}}
{{- end -}}

{{/*
Render the caBundle volume entry. Caller must guard on the component's
caBundleEnabled flag.
*/}}
{{- define "cosmonic-control.caBundleVolume" -}}
{{- include "cosmonic-control.caBundleValidate" . -}}
- name: ca-bundle
  {{- if .Values.caBundle.existingSecret }}
  secret:
    secretName: {{ .Values.caBundle.existingSecret }}
  {{- else if .Values.caBundle.existingConfigMap }}
  configMap:
    name: {{ .Values.caBundle.existingConfigMap }}
  {{- else }}
  configMap:
    name: {{ include "cosmonic-control.caBundleConfigMapName" . }}
  {{- end }}
{{- end -}}

{{/*
Render the caBundle volumeMount entry. Caller must guard on the component's
caBundleEnabled flag.
*/}}
{{- define "cosmonic-control.caBundleVolumeMount" -}}
- name: ca-bundle
  mountPath: {{ .Values.caBundle.mountPath }}
  subPath: {{ if .Values.caBundle.existingSecret }}{{ .Values.caBundle.secretKey }}{{ else }}{{ .Values.caBundle.configMapKey }}{{ end }}
  readOnly: true
{{- end -}}
