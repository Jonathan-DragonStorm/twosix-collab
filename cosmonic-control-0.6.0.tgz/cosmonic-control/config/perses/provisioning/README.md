# Perses Provisioning

> [!NOTE]
> This directory is for perses resources that come standard with Cosmonic Control. Custom dashboards or datasources should be added using one of the following methods:
> 1. Create a ConfigMap in your cluster that has the label that matches the key/value defined in the `values.yaml` file for this chart. By default, this is `cosmonic.io/perses-resource=sync`.
> 2. Add the YAML files directly to the values file under the `perses.provisioning.extraProvisioningFiles` key as a map of filename to file contents.

This directory contains configuration files for provisioning dashboards, datasources, and other resources in Perses. These files are organized in a way that mirrors the structure expected by Perses for its file-based storage backend. We're doing this on purpose so that in development, we can just mount this directory as a volume in the Perses container and have it pick up the configuration automatically.

When deploying to production, these files are bundled into a Kubernetes ConfigMap which is then mounted into the Perses container.

## File Structure
The files have some specific naming and organizational requirements so make sure to follow these conventions.

```hbs
projects/
  ├── {{project-name}}.yaml <!-- name must match metadata.name -->
  └── ...
dashboards/
  └── {{project-name}}/ <!-- directory name must match a valid project -->
      ├── {{dashboard-name}}.yaml <!-- name must match metadata.name and have -->
      └── ...
globaldatasources/
  ├── {{datasource-name}}.yaml <!-- name must match metadata.name -->
  └── ...
```
